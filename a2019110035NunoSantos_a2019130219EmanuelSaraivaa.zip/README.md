Project created in the context of data integration module in my university
