package cidadesdomundo;

import java.io.IOException;

/**
 *
 * @author Nuno
 */
public class TP {

    public static void main(String[] args) throws IOException {
        /*String lista = "Nova Iorque, Estados Unidos";
        String[] campos = lista.split(", ");
           
        String link = Wrappers.encontrarLinkDBCityPais(campos[1],campos[0]);
        System.out.println("link cidade " + link);*/
    }
}
